function [Istck6, MaxN] = a20250428_spinemeasure_sub06(Istck5, Istck3B, Istck3C, Istck3D, MaxN)

%***********************************************************************
%Using Istck3B, Istck3C, and Istck3D, large voxel clusters around the shaft
%are removed
%Inputs are matrix to be processed (Istck5), three model shafts (IstckB,
%IstckC, and IstckD) with different diameters, and the number of spine
%candidates (MaxN)
%Output is voxels after removal of shaft surface voxels (Istck6) and number 
% of spine candidates (MaxN)
%***********************************************************************
if MaxN >0
    Nsize = size (Istck5);
    Istck6 = zeros(Nsize(1), Nsize(2), Nsize(3));
    Ncount = 1;
for k=1:MaxN
    %Pick up kth spine candidate
    CheckM = Istck5==k;
    VoxelNo = sum(sum(sum(CheckM)));
    if VoxelNo > 5000
        %If voxel size is more than 5000, start evaluate overlap with shaft
        %CheckMB,C,D are overlap with shaft volume with different radius
        CheckMB = (CheckM.*Istck3B) >0;
        CheckMC = (CheckM.*Istck3C) >0;
        CheckMD = (CheckM.*Istck3D) >0;
        %Calculate voxel numbers for thre overlap volumes
        VoxelNoB = sum(sum(sum(CheckMB)));
        VoxelNoC = sum(sum(sum(CheckMC)));
        VoxelNoD = sum(sum(sum(CheckMD)));

        %If overlap is large with three shaft models, remove the overlap
        if VoxelNoB > 500 && (VoxelNo - VoxelNoB) > 98
           CheckM = CheckM-k*CheckMB;
        end
        if VoxelNoB < 500 && VoxelNoC > 500 && (VoxelNo - VoxelNoC) > 98
            CheckM = CheckM-k*CheckMC;
        end
        if VoxelNoB < 500 && VoxelNoC < 500 &&VoxelNoD > 500 && (VoxelNo - VoxelNoD) > 98
            CheckM = CheckM-k*CheckMD;
        end
        %if overlap is not very large, the spine candidate is not altered
        if VoxelNoB < 1250
            Istck6 = Istck6 + Ncount*CheckM;
            Ncount = Ncount +1;
        end
    else
        Istck6 = Istck6 + Ncount*CheckM;
        Ncount = Ncount +1;
    end
end
MaxN = Ncount-1;
end
