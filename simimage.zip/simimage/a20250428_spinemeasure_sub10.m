function [spinecell2, junctcell2] = a20250428_spinemeasure_sub10(Istck10, IstckJunction3, newK, OptYZ)
%rotae spines and align them to be in the xy plane and perpendicular to the
%axis of dendritic shaft
%Obtain size information of 3D image matrix
    Nsize = size(Istck10);
%Generate new Cell to store individual spine data
    spinecell = cell(1,newK);
    junctcell = cell(1,newK);
    centroidX = zeros(1, newK);
for k = 1:newK
    %Select the kth spine junction and get voxel information
    junctionindex = Istck10 == k;
    junctionindex2 = IstckJunction3 == k;
    %calculate total pixels of kth spine
    sumjunction = sum(junctionindex, 'all');
    %make pixel number profile along X axis
    junctionX = squeeze(sum(sum(junctionindex, 3), 1)).';
    %calculate centroid of spine along X axis
    centroidX(k) = int16(sum(junctionX.*([1:1:Nsize(2)].'))/sumjunction);
    %make pixel number profile along Y axis
    junctionY = squeeze(sum(sum(junctionindex, 3), 2));
    %calculate centroid of spine along Y axis
    centroidY = (sum(junctionY.*([1:1:Nsize(1)].'))/sumjunction);
    %make pixel number profile along Z axis
    junctionZ = squeeze(sum(sum(junctionindex, 2), 1));
    %calculate centroid of spine along Z axis
    centroidZ = (sum(junctionZ.*([1:1:Nsize(3)].'))/sumjunction);
    %generate two vectors to calculate the angle
    axis1 = [1 0];
    axis2 = [centroidY - OptYZ(1, centroidX(k)), 1*(centroidZ - OptYZ(2, centroidX(k)))];
    %calculate the angle between Y direction and vector in the direction
    %from shaft center to spine center
    angle = acosd(dot(axis1, axis2, 2)./sqrt(dot(axis1, axis1,2).*dot(axis2, axis2,2)));
    %Select the kth spine and get voxel information
    spineindex = find((Istck10 == k) + (IstckJunction3 == k));
    %From spineindex, restore x, y, z values
    Zsize = floor(spineindex/(Nsize(1)*Nsize(2)))+1;
    Residual = rem(spineindex,(Nsize(1)*Nsize(2)));
    Xsize = floor(Residual/Nsize(1))+1;
    Ysize = rem(Residual,Nsize(1));
    %From the restored positions, obtain max and min X, Y, Z values
    Xmax = max(Xsize);
    Xmin = min(Xsize);
    Ymax = max(Ysize);
    Ymin = min(Ysize);
    Zmax = max(Zsize);
    Zmin = min(Zsize);
    %For the kth spine and junction, generate 3D matrix as a container
    Cpre = zeros(Ymax-Ymin+3, Xmax-Xmin+3, Zmax-Zmin+3);
    Cpre2 = zeros(Ymax-Ymin+3, Xmax-Xmin+3, Zmax-Zmin+3);
    %From the 3D image matrix, isolate voxels for kth spine
    Istck10k = Istck10 == k;
    %To the container, spine and junction vortex values are loaded
    Cpre(2:(Ymax-Ymin+2), 2:(Xmax-Xmin+2), 2:(Zmax-Zmin+2)) = Istck10k(Ymin:Ymax, Xmin:Xmax, Zmin:Zmax);
    Cpre2(2:(Ymax-Ymin+2), 2:(Xmax-Xmin+2), 2:(Zmax-Zmin+2)) = junctionindex2(Ymin:Ymax, Xmin:Xmax, Zmin:Zmax);
    %As Z voxel size is one fourth of XY resolution, expand 3D matrix in this
    %direction
    C = repelem(Cpre, 1, 1, 4);
    C2 = repelem(Cpre2, 1, 1, 4);
    %rotate the volume along X axis
    spinerotate = imrotate3(C, angle, [1 0 0]);
    junctrotate = imrotate3(C2, angle, [1 0 0]);
    %place image matrix in cells
    spinecell(k) = {spinerotate};
    junctcell(k) = {junctrotate};

end
%change order of spines from left to right
[~, Order] = sort(centroidX);
%prepare new cells to put data    
spinecell2 = cell(1,newK);
junctcell2 = cell(1,newK);
for k = 1:newK
    %record spine data from left to right
    spinecell2{k} = spinecell{int16(Order(k))};
    junctcell2{k} = junctcell{int16(Order(k))};
end

