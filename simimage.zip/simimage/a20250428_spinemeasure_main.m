%*************************************************************************
%Main program "a20250428_spinemeasure_main" for spine detection and shape
%analysis
%This program loads TIF stack from SIM microscope
%Put your multiple TIF stack file in the current working directory with the
%file name of "image1", "image2", "image3".....
%Program saves pseudocolor TIF images for individual spines (spineimage1,
%spineimage2, ...)
%with binalized images of dendrite (outputimageA1) and isolated spines
%(outputimageB1)
%together with an Excel file containing shape data for each spine
%(datamatrix1, datamatrix2,...)

%This program requires the following associated functions
%"a20250428_spinemeasure_sub01"; function to use maximum filter to stack image
%"a20250428_spinemeasure_sub02"; function to generate binalized image
%"a20250428_spinemeasure_sub03"; function to find isolated dendrite
%"a20250428_spinemeasure_sub04"; function to isolate and rotate main dendritic shaft
%"a20250428_spinemeasure_sub05"; function to find main dendritic shaft
%"a20250428_spinemeasure_sub06"; function to remove residual voxels around shaft
%"a20250428_spinemeasure_sub07"; function to find non-spine voxel clusters
%"a20250428_spinemeasure_sub08"; function to adjust spine-shaft junction
%"a20250428_spinemeasure_sub09"; function to remove spines with multiple necks
%"a20250428_spinemeasure_sub10"; function to adjust angles of spines
%"a20250428_spinemeasure_sub11"; function to calculate spine shape
%"a20250428_spinemeasure_sub12"; subroutine for "a20250428_spinemeasure_sub11"


%*************************************************************************
%Clear previous data
clear
%put number of dendrite images to process
RepeatNumber = 1;
%totalK is zero for new analysis, if it follows the previous analysis, set
%totalK as the last spine number
totalK = 0;
%if dendrite images contain multiple segments, set multi = 1 
% else multi = 0;
multi =0;

%start repeat of different dendrite images
for serialN = 1:RepeatNumber

%create file name such as "image1.tif"
inputname = 'image';
nametif = '.tif';
namenumber = sprintf('%d', serialN);
fname= [inputname namenumber nametif];

%Obtain information of image file
info = imfinfo(fname);

%Set value for the adjustment to the estimated radius of the dendritic shaft
Rplus = -1;
%Number of images in the stack is obtained as "num_images"
num_images = numel(info);
%Read the first TIF image to "Isize"
%Obtain pixel sizes in X and Y axis of "Isize"
Nsize = size(imread(fname));
%Generate a sphere with its radius of 4
se4 = strel('sphere',4);

%*************************************************************************
%START loading each image
%*************************************************************************
Istck1 = zeros(Nsize(1), Nsize(2), num_images);
for k = 1:num_images
    %kth image in the stack is stored in the matrix "imagebuffer"
    imagebuffer = imread(fname, k, 'Info', info);
    Istck1(:,:,k) = imagebuffer;
end
%*************************************************************************
%END loading each image
%*************************************************************************


%*************************************************************************
%ESTART fill inside of shaft using Maxfilter function
%*************************************************************************
[Istck1B] = a20250428_spinemeasure_sub01(Istck1);
%*************************************************************************
%END fill inside of shaft using Maxfilter function
%*************************************************************************

%Binalize image by active_contour
Coeff = 1.7; %for DiI
%Coeff = 1.1; %for GFP
[PreIstck1] = a20250428_spinemeasure_sub02(Istck1, Coeff);
Coeff = 0.8;
[PreIstck1B] = a20250428_spinemeasure_sub02(Istck1B, Coeff);
if multi == 1
%*************************************************************************
%START Identify the isolated dendrite
%*************************************************************************
[Istck1, Istck1B] = a20250428_spinemeasure_sub03(PreIstck1, PreIstck1B);
%*************************************************************************
%ENDIdentify the isolated dendrite
%*************************************************************************
else
    Istck1=PreIstck1;
    Istck1B=PreIstck1B;
end
if sum(Istck1, 'all') >0

%*************************************************************************
%START Identify the main dendritic shaft and rotate image
%to make main shaft horizontal
%*************************************************************************
[Istck1, Istck1B] =  a20250428_spinemeasure_sub04(Istck1, Istck1B);
%*************************************************************************
%END Identify the main dendritic shaft and rotate image
%to make main shaft horizontal
%*************************************************************************

if sum(Istck1, 'all') >0

%*************************************************************************
%START Estimate voxels corresponding to dendritic shaft
%*************************************************************************
%Istck2 = isolated total dendrite voxels
%Istck3A = isolated dendrite shaft
%Istck3B, 3C, 3D = isolated dendritic shafts with increasing diameters
[Istck2, Istck3A, Istck3B, Istck3C, Istck3D, OptYZ] = a20250428_spinemeasure_sub05(Istck1, Istck1B, Rplus);
%*************************************************************************
%END Estimate voxels corresponding to dendritic shaft
%************************************************************************* 

%Isolate spines by subtracting shaft voxels from the dendrite voxels
Istck4 = (Istck2-Istck3A) > 0;
%Identify voxel clusters corresponding to single spine candidate
Istck5 = bwlabeln(Istck4,26);
%Calculate number of spine candidates
MaxN = max(max(max(Istck5)));

%*************************************************************************
%START remove large residual voxels around dendritic shaft
%*************************************************************************
[Istck6] = a20250428_spinemeasure_sub06(Istck5, Istck3A, Istck3B, Istck3C, MaxN);
%*************************************************************************
%END remove large residual voxels around dendritic shaft
%*************************************************************************


%*************************************************************************
%START Remove voxel clusters (too long, too small, at the edge of image)
%from spine candidates
%*************************************************************************
 [Istck7, newK] = a20250428_spinemeasure_sub07(Istck6, Istck2, MaxN);
%*************************************************************************
%END Remove voxel clusters (too long, too small, at the edge of image)
%from spine candidates
%*************************************************************************

%From the entire denrite voxels, remove spine voxels
%This will generate voxels corresponding to non-spine volume
IstckBorder = (Istck2 - Istck6)>0 ;

%*************************************************************************
%START Adjust positions of spine-shaft junctions
%*************************************************************************
 [Istck8,Istckjunction] = a20250428_spinemeasure_sub08(Istck7, IstckBorder, newK);
%*************************************************************************
%END Adjust positions of spine-shaft junctions
%*************************************************************************


%*************************************************************************
%START Remove spines with multiple attachment to shaft
%*************************************************************************
%Identify voxel clusters corresponding to single spine candidate
%Re-numbering of spine clusters
Istck9 = bwlabeln(Istck8,26);
newK = max(max(max(Istck9)));
%Generate voxel assembly that represent non-spine volume
IstckBorder2 = (Istck2 - Istck8 - Istck6)>0 ;
[Istck10, IstckJunction3, newK] = a20250428_spinemeasure_sub09(Istck9, IstckBorder2, newK);
%*************************************************************************
%END Remove spines with multiple attachment to shaft
%*************************************************************************

if newK > 0
%*************************************************************************
%START Isolate single spines and adjust their angles
%*************************************************************************
[spinecell2, junctcell2] = a20250428_spinemeasure_sub10(Istck10, IstckJunction3, newK, OptYZ);
%*************************************************************************
%END Isolate single spines and adjust their angles
%*************************************************************************


%*************************************************************************
%START Isolate single spines and adjust their angles
%*************************************************************************
 [Spinedata, newK] = a20250428_spinemeasure_sub11(spinecell2, junctcell2, newK, totalK);
%*************************************************************************
%END Isolate single spines and adjust their angles
%*************************************************************************
totalK = totalK + newK;

%*************************************************************************
%START Save data
%*************************************************************************
%creat matrix for data saving
summarymatrix = zeros(newK, 64);
%from Spinedata cell, read invididual data(64 data points in total for each
%spine)
for i=1:newK
    %spine length data (1 data point)
    summarymatrix(i, 1) = Spinedata{1,i};
    %spine surface and junction surface data (2 data points)
    summarymatrix(i, 2:3) = Spinedata{2,i};
    %spine volume data (1 data point)
    summarymatrix(i, 4) = Spinedata{3,i};
    %volume data for individual segments along spine axis (20 data points)
    summarymatrix(i, 5:24) = Spinedata{4,i}.';
    %(convexhull-spine volume)/convexhull data for each segment (20 data points)
    summarymatrix(i, 25:44) = Spinedata{5,i}(:,1).';
    %convexhull-spine volume for each segment (20 data points) 
    summarymatrix(i, 45:64) = Spinedata{5,i}(:,2).';
end
%creat labes for 64 data points
Label = {'length', 'surface', 'base surface', 'volume', 'segvol1', 'segvol2', 'segvol3', 'segvol4', 'segvol5', 'segvol6', 'segvol7', 'segvol8', 'segvol9', 'segvol10', 'segvol11', 'segvol12', 'segvol13', 'segvol14', 'segvol15',  'segvol16', 'segvol17', 'segvol18', 'segvol19', 'segvol20', 'CHR1', 'CHR2', 'CHR3', 'CHR4', 'CHR5', 'CHR6', 'CHR7', 'CHR8', 'CHR9', 'CHR10', 'CHR11', 'CHR12', 'CHR13', 'CHR14', 'CHR15', 'CHR16', 'CHR17', 'CHR18', 'CHR19', 'CHR20','CHV1', 'CHV2', 'CHV3', 'CHV4', 'CHV5', 'CHV6', 'CHV7', 'CHV8', 'CHV9', 'CHV10', 'CHV11', 'CHV12', 'CHV13', 'CHV14', 'CHV15', 'CHV16', 'CHV17', 'CHV18', 'CHV19', 'CHV20'};
summarytable = array2table(summarymatrix, 'VariableNames', Label);
%create file name such as "datamatrix1.tif"
inputname2 = 'datamatrix';
namexls = '.xls';
fname2= [inputname2 namenumber namexls];
%write Table as excel file
writetable(summarytable, fname2,'Sheet',1);
%write image of selected dendritic shaft as TIF file
inputname3 = 'outputimageA';
fname3= [inputname3 namenumber nametif];
imwrite(sum(Istck1, 3), fname3);
%write image of isolated spines as TIF file
inputname4 = 'outputimageB';
fname4= [inputname4 namenumber nametif];
imwrite(sum(Istck10, 3), fname4);
%*************************************************************************
%END Save data
%*************************************************************************
end
end
end
end
