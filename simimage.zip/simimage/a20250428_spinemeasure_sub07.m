function [Istck3, MaxN2] = a20250428_spinemeasure_sub07(Istck, totalIstck, MaxN)

%*************************************************************************
%This function uses "Istck", TIF stack file for individual spines, 
%"totalItsck", TIF binary stack file for entire dendrite,and "MaxN", the number of
%spine candidates, judges whether spine candidates should be acepted or
%rejected from their size, shape, and location
%The outputs of the function are "Istck3", the image stuck from which
%non-spine voxel clusters are removed and "MaxN2", which provides the new
%number of spine candidates
%*************************************************************************

%*************************************************************************
%START Remove objects too small, too elongated, or located at image edges 
%*************************************************************************
%Check size of 3D image matrix
Nsize = size(Istck);
%Create new 3D image matrix
Istck2 = zeros(Nsize(1), Nsize(2), Nsize(3));
%Prepare vectors for storing parameters
OrderNo = zeros(MaxN,2);
CheckMsize = zeros(MaxN, 1);
CheckM2size = zeros(MaxN, 1);
CheckMRatio = zeros(MaxN, 1);
MaxN2 = 0;
%Generate voxels corresponding to non-spine volume
shaftIstck = (totalIstck - Istck)>0;

%Generate a sphere with its radius of 2
se = strel('sphere',2);
%MaxN should be more than 0
if MaxN >0
%START evaluation of indvidual spine candidates
for k = 1:MaxN
    %Isolate kth spine candidate
    CheckM1 = Istck==k;
    %Expand matrix in Z direction 4 times
    CheckM = repelem(CheckM1, 1, 1, 4);
    %Select spine candidates larger than 400 voxel�icorresponding to 0.01 cubic micron)
    %and not at the edge of image field
    
    IstckJunction = imdilate(CheckM1, se).*shaftIstck;   
    SpineVal = sum(sum(sum(CheckM1)));
    SpineVal4 = sum(sum(sum(CheckM)));
    JunctionVal = sum(sum(sum(IstckJunction)));
    JunctionRatio = JunctionVal / SpineVal;
    
    %Check if spine is in the adequate size (400<volume<90000) and spine is
    %not at the edge of image size
    if SpineVal4 > 400 && SpineVal4 < 90000 && sum(sum(sum(CheckM(:,1:3,:)))) == 0 && sum(sum(sum(CheckM(:,Nsize(2)-2:Nsize(2), :)))) == 0
        
        %Check if the spine juction volume is not very large and is more than zero 
        if JunctionRatio < 2 && JunctionVal > 0
    
    
        %START evaluation if the object is elongated along X axis
        %Find maximun and minimu in X value of object
        [~,MXrange] = find(sum((sum(CheckM,3)),1));
        %Calculate the total voxel size of spine candidate
        CheckMsize(k) = sum(sum(sum(CheckM,3),2),1);
        %Calculate the largest cross-section of spine candidate in YZ plane
        CheckM2size(k) = max(sum(sum(CheckM,3),1));
        %Calculate the ratio of cross-section against X axis length
        CheckMRatio(k) = CheckM2size(k)/(max(MXrange)-min(MXrange));
        %If the ratio is larger than 1 or 2, dependent on spine size,
        %it is judged not to be elongated
        if (CheckMRatio(k) > 1 && CheckMsize(k) < 12000) || (CheckMRatio(k) > 2 && CheckMsize(k) >= 12000)
            %Count the number of spine candidates that passed the test
            MaxN2 = MaxN2 +1;
            %To the new 3D matrix, input voxel value of MaxN2
            Istck2 = Istck2 + CheckM1*MaxN2;   
            %Integrate voxel values to X axis to estimate the spine position
            Order = sum(sum(CheckM1, 3),1);
            %Obtain X position of the most lefthand voxel of the spine
            OrderNo(MaxN2,:) = [find(Order,1), MaxN2];
        end
        end
    end
end

%MaxN2 should be more than 0
if MaxN2>0
    Istck3 = zeros(Nsize(1), Nsize(2), Nsize(3));
    %OrderNo vector contains zero values, corresponding to candidates judged
    %to be not spines These elements are identified
    IndOrderNo = OrderNo(:,1)>0;
    %From OrderNo vector, remove the rows with zero elements
    OrderNo = OrderNo(IndOrderNo,:);
    %Reorder elements of OrderNo from smaller to larger values
    %For this purpose, first reorder OrderNo along the X positions in the first
    %column
    ReOrderNo = sortrows(OrderNo);
    for k = 1:MaxN2
        %Add new spines of value k to Istck3 with the order specified by
        %ReOrderNo
        Istck3 = Istck3 + (Istck2 == ReOrderNo(k,2))*k;
    end

else
    Istck3 = Istck;
end

else
    Istck3 = Istck;
end
%*************************************************************************
%END Remove objects too small, too elongated, or located at image edges 
%*************************************************************************