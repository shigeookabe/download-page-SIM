function [Spinedata, newK2] = a20250428_spinemeasure_sub11(spinecell, junctcell, newK, totalK)

%From isolated spine volume and spine junction volume ("spinecell" and "junctcell"), 
%calculate multiple structural parameters using another subfunction
%"a20250428_spinemeasure_sub12"
%Calculated numbers are output as "Spinedata" matrix

se5 = strel('sphere',5);
%Apex(k) is cell containing 20 of 3D pixels with k-times repeated deletion 
%fromproximal segments
Apex = cell(1,20);
%Base is cell containing 20 of segmented 3D pixels tha was used for
%deletion to generate Apex(k)
Base = cell(1,20);
%prepare cell to record results of measurement
Spinedata = cell(5, newK);
newK2 = 0;
%prepare matrix Branchscore for recording all spine branches 
Branchscore = zeros(newK, 20);
for k = 1:newK
    %isolate kth spine and junction
    spineMat = spinecell{k}>0;
    junctMat = junctcell{k}>0;
    %generate first base volume
    InitialBase = spineMat.*junctMat;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START Judge spine has multiple heads if so isolate largest one
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %subtraction of base may make spine volume into two clusters -detect
    %these clusters
    %bwconncomp = Find connected components in binary image
    CC = bwconncomp(spineMat - InitialBase);
    %count voxel size (PixelIdList is index for "bwconncomp")
    %PixelIdList = 1-by-NumObjects cell array where the k-th element in the cell 
    %array is a vector containing the linear indices of the pixels 
    %in the k-th object. (NumObjexts is another index for the number of
    %isolated objects
    numPixels = cellfun(@numel,CC.PixelIdxList);
    %find the largest isolated object
    [~,idx] = max(numPixels);
    %crate new 3D matrix
    Nsize = size(spinecell{k});
    ApexMat = zeros(Nsize(1), Nsize(2), Nsize(3));
    %put largest spine fragmen to new matrix
    ApexMat(CC.PixelIdxList{idx}) = 1;
    Apex{1} = ApexMat;
    Base{1} = imdilate(Apex{1}, se5).*InitialBase;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END Judge spine has multiple heads if so isolate largest one
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %generate Sum of apical volume (Sum is 3D matrix to integrate pixel
    %intensities (for pseudocolor presentation)
    Sum = Apex{1};
    %Matnumber is matrix to store total pixel number for Apex and Base
    Matnumber = zeros(20,2);
    Matnumber(1,:) = [sum(Apex{1}, 'all'), sum(Base{1}, 'all')];
    %Count number of clusters in the first Base
    CBase = bwconncomp(Base{1});
    %Store kth Branch in Branchscore
    Branchscore(k, 1)  = CBase.NumObjects;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START divide spine into multiple segments
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %repeat finding new segments for 20 times
    for i = 2:20
        %isolate new base voxels
        Base{i} = imdilate(Base{i-1}, se5).*Apex{i-1};
        %isolate new apex voxels
        Apex{i} = Apex{i-1} - Base{i};
        %calculate voxel numbers of apex and base
        Matnumber(i,:) = [sum(Apex{i}, 'all'), sum(Base{i}, 'all')];
        %add new apex to the Sum of the previous apex
        Sum = Apex{i} + Sum;
        %Count number of clusters in the ith Base
        CBase = bwconncomp(Base{i});
        %Store kth Branch in Branchscore
        Branchscore(k, i) = CBase.NumObjects;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END divide spine into multiple segments
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %Judge ith spine to be kept or not
    JudgeA = 0;
    %If spine is too small, it is excluded (small)
    if Matnumber(1,1) < 2000
        JudgeA = 1;
    end
    %If spine is flat, it is excluded (small)
    if Matnumber(6,2) == 0 && Matnumber(1,2) >1500
        JudgeA = 1;
    end
    %If spine is flat, it is excluded (large)
    if Matnumber(12,2) == 0 && Matnumber(1,2) >6000
        JudgeA = 1;
    end

    Baseplane = sum(Base{1}, 3);
    Xwidth = find(sum(Baseplane, 1),1,'last')-find(sum(Baseplane, 1),1,'first');
    Ywidth = find(sum(Baseplane, 2),1,'last')-find(sum(Baseplane, 2),1,'first');
    XYDist = sqrt(Xwidth*Xwidth + Ywidth*Ywidth);
    if XYDist > 60
        JudgeA = 1;
    end
    
    %If spine has a few branch, not short, not flat, it is processed
    SumBranch = sum(Branchscore(k, 1:5));
    if Branchscore(k, 1)  ==1 && Matnumber(3,2) >0 && SumBranch < 9 && JudgeA == 0
    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START classify unbranched, branched, and merged spines
    %JudgeB == 0 spine unbranched
    %JudgeB == 1 spine branched
    %JudgeB == 2 spine merged
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        

    JudgeB = 0;
    %Small spines are taken as unbranched; Large (>10000) are judged   
    if sum(Apex{1}, 'all') > 10000
        %Find the tip length
        TipNo = find(Matnumber(:,1) , 1, 'last');
        HalfTipNo = floor(2*TipNo/3);
        ThirdTipNo = floor(TipNo/3);
        NCountSect = zeros(1, HalfTipNo-ThirdTipNo+1);
        NCountObj = zeros(1, HalfTipNo-ThirdTipNo+1);
        for i = ThirdTipNo:HalfTipNo
            %Numbeor of cross setions at i+1
            CountSect= bwlabeln(Base{i+1},26);
            NCountSect(i-ThirdTipNo+1) = max(max(max(CountSect)));
            %Number of distal volumes at i
            CountObj = bwlabeln(Apex{i},26);
            NCountObj(i-ThirdTipNo+1) = max(max(max(CountObj)));         
        end 

        %If NCountSect is >1, spine might be branched
        if max(NCountSect) >1
            %Find branch segments and their distal object number
            Brseg = NCountObj(find(NCountSect>1));
            %Remaining spines may have two distal branches
            %Most proximal branch point is detected
            FirstN = find(NCountSect>1, 1, 'first')+ThirdTipNo;
            %Isolated sections are numbered at the proximal branch point
            CountSect = bwlabeln(Base{FirstN},26);
            %Count the number of total voxels in this segment
            TotalN = sum(Base{FirstN}, 'all');
            %Count number of isolaed sections
            MaxN = max(max(max(CountSect)));
            %For ecah isolated section, count the voxel number
            for i = 1:MaxN
                NCountSect2(i) = sum(CountSect ==i, 'all');               
            end
            %Sort voxel numbers in descending direction
            NCountSect3 = sort(NCountSect2, 'descend');
            
            
            %If any of distal object numbers are 1, judged as merged spines
            if sum(Brseg == 1) > 0
                %objects distal to the branch point are 1 and the largest
                %section is <80% of the total distal volume
                if NCountSect3(1) < TotalN*0.8
                    %judged as merged spine
                    JudgeB = 2;
                else
                    %otherwise judge as unbranced spine
                    JudgeB = 0;
                end
            %If any of distal object numbers are 0, judged as unbranched or
            %branced spines
            else
                %If the largest and second largest isolated sections are
                %large enough, they are taken as two main spine branches
                if NCountSect3(2) > NCountSect3(1)*0.3 && (NCountSect3(1)+NCountSect3(2)) > TotalN*0.9 && NCountObj(FirstN-ThirdTipNo) > 1                  
                    JudgeB = 1;
                %otherwise judge as unbranched spine
                else
                    JudgeB = 0;
                end
            end
        end
    end
    %All spines are classified as unbranched (0), branched (1), or merged (2)

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END classify unbranched, branched, and merged spines
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %prepare jundgement parameters
    JudgeC = 0;
    JudgeD = 0;
    JudgeE = 0;
    JudgeF = 0;
    %confirm there is no "zero volume" spine
    if sum(Apex{1}, 'all') == 0
        JudgeE = 1;
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START separation of branched spine (largest and second largest
    %branches)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if JudgeB ==1
        %prepare new cells to store volume data
        Apex2 = cell(2,20);
        Base2 = cell(2,20);
        %find proximal branch point
        FirstN2 = find(NCountObj>1, 1, 'first')+ThirdTipNo-1;
        %count number of distal objects
        CountVol = bwlabeln(Apex{FirstN2},26);
        MaxN2 = max(max(max(CountVol)));
        %treat independent distal objects (n=MaxN2) to count total voxels
        for i = 1:MaxN2
            NCountObj2(i) = sum(CountVol ==i, 'all');               
        end
        %pick up largest and second largest objects
        [~, SpineN] = maxk(NCountObj2, 2);
        Apex2{1,1} = CountVol==SpineN(1);
        Apex2{2,1} = CountVol==SpineN(2);
        Base2{1,1} = imdilate(Apex2{1,1}, se5).*Base{FirstN2};
        Base2{2,1} = imdilate(Apex2{2,1}, se5).*Base{FirstN2};
        
        %first Apex cell contains total branch objects
        Sum1 = Apex2{1,1};
        Sum2 = Apex2{2,1}; 
        %Matnumber is matrix to store total pixel number for Apex and Base
        Matnumber2 = zeros(2,20,2);
        Matnumber2(1,1,:) = [sum(Apex2{1,1}, 'all'), sum(Base2{1,1}, 'all')];
        Matnumber2(2,1,:) = [sum(Apex2{2,1}, 'all'), sum(Base2{2,1}, 'all')];
        
        %check if new two branches are not empty
        if sum(Apex2{2,1}, 'all') == 0
            JudgeD = 1;
        end
        if sum(Apex2{1,1}, 'all') == 0
            JudgeF = 1;
        end

        %start segmenting new branches
        for i = 2:20
        %isolate new base voxels
        Base2{1,i} = imdilate(Base2{1,i-1}, se5).*Apex2{1,i-1};
        Base2{2,i} = imdilate(Base2{2,i-1}, se5).*Apex2{2,i-1};
        %isolate new apex voxels
        Apex2{1,i} = Apex2{1,i-1} - Base2{1,i};
        Apex2{2,i} = Apex2{2,i-1} - Base2{2,i};
        %calculate voxel numbers of apex and base
        Matnumber2(1,i,:) = [sum(Apex2{1,i}, 'all'), sum(Base2{1,i}, 'all')];
        Matnumber2(2,i,:) = [sum(Apex2{2,i}, 'all'), sum(Base2{2,i}, 'all')];
        %add new apex to the Sum of the previous apex
        Sum1 = Apex2{1,i} + Sum1;
        Sum2 = Apex2{2,i} + Sum2;
        end
        %summation of volumes is stored in a single cell
        Sum3 = cell(2);
        Sum3{1} = Sum1; Sum3{2} = Sum2;

        %check if second branch is large enough
        if sum(Apex2{2,1}, 'all') <2000
            JudgeC = 1;
        end
       
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END separation of branched spine (largest and second largest
    %brances)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    JudgeB;
    JudgeC;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START if JudgeB and JudgeE are both zero, spine is large enough and
    %unbranched
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if JudgeB ==0 && JudgeE ==0 
        newK2 = newK2 +1;
        %START calculate morphological parameters
        [SpineMat] = a20250428_spinemeasure_sub12(Apex, Base, Sum, Matnumber,newK2, Nsize, totalK);      
        %record spine length (1st row)
        Spinedata{1, newK2} = SpineMat{1};
        %record surface area of spine and junction (2nd row)
        Spinedata{2, newK2} = SpineMat{2};
        %record spine volume (3rd row)  
        Spinedata{3, newK2} = SpineMat{3};
        %record volume for each segment (4th row)
        Spinedata{4, newK2} = SpineMat{4};
        %record convexhull ratio and its volume for each segment (5th row)
        Spinedata{5, newK2} = SpineMat{5};
        %END calculate morphological parameters
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END if JudgeB and JudgeE are both zero, spine is large enough and
    %unbranched, single data is stored
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START if JudgeB is one and JudgeC is zero, spine is branched and
    %second branch is large enough
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if JudgeB ==1 && JudgeC == 0
    %start storing two branches
        for i=1:2
            %check first or second branch is not empty
            if (JudgeF == 0 && i == 1) || (JudgeD == 0 && i == 2)
                newK2 = newK2 +1;
                Apex = Apex2(i,:);
                Base = Base2(i,:);
                Sum = Sum3{i};
                Matnumber(:,:) = squeeze(Matnumber2(i,:,:)) ;
        
                %START calculate morphological parameters  
                [SpineMat] = a20250428_spinemeasure_sub12(Apex, Base, Sum, Matnumber,newK2, Nsize, totalK);      
                %record spine length (1st row)
                Spinedata{1, newK2} = SpineMat{1};
                %record surface area of spine and junction (2nd row)
                Spinedata{2, newK2} = SpineMat{2};
                %record spine volume (3rd row) 
                Spinedata{3, newK2} = SpineMat{3};
                %record volume for each segment (4th row)
                Spinedata{4, newK2} = SpineMat{4};
                %record convexhull ratio and its volume for each segment (5th row)
                Spinedata{5, newK2} = SpineMat{5};
                %END calculate morphological parameters
             end
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END if JudgeB and JudgeE are both zero, spine is large enough and
    %unbranched, single data is stored
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START if JudgeB and JudgeC are one, spine is branched and
    %second branch is too small
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if JudgeB ==1 && JudgeC == 1
        newK2 = newK2 +1;
        Apex = Apex2(1,:);
        Base = Base2(1,:);
        Sum = Sum3{1};
        Matnumber(:,:) = squeeze(Matnumber2(1,:,:)) ;      
        %START calculate morphological parameters  
        [SpineMat] = a20250428_spinemeasure_sub12(Apex, Base, Sum, Matnumber,newK2, Nsize, totalK);      
        %record spine length (1st row)
        Spinedata{1, newK2} = SpineMat{1};
        %record surface area of spine and junction (2nd row)
        Spinedata{2, newK2} = SpineMat{2};
        %record spine volume (3rd row) 
        Spinedata{3, newK2} = SpineMat{3};
        %record volume for each segment (4th row)
        Spinedata{4, newK2} = SpineMat{4};
        %record convexhull ratio and its volume for each segment (5th row)
        Spinedata{5, newK2} = SpineMat{5};
        %END calculate morphological parameter   
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END if JudgeB and JudgeC are one, spine is branched and
    %second branch is too small
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    end
    
    
end
