function [Istck6B, IstckJunction3, newK] = a20250428_spinemeasure_sub09(Istck6, IstckBorder2, newK)

%Identify voxel clusters corresponding to single spine candidate
%Remove spines that connect to the shaft at two different positions
%If a spine has two distinct branches, they are separated and 
%recorded as two different spines

%Find the size of matrix Istck6
Nsize = size(Istck6);
%Generate a sphere with its radius of 1 or 4
se1 = strel('sphere',1);
se4 = strel('sphere',4);

%Dilate voxel clusters in the shaft
IstckBorder3 = imdilate(IstckBorder2, se1);
%Prepare new 3D matrix for spine voxels
Istck6B = zeros(Nsize(1), Nsize(2), Nsize(3));
%Prepare new 3D matrix for junction voxels
IstckJunction3 = zeros(Nsize(1), Nsize(2), Nsize(3));

if newK > 0
%Start judgement of spines one by one
kcount=1;
NCheckM2 = zeros(1,newK);
NCheckM4 = zeros(1,newK);
for k=1:newK
    %Isolate kth spine
    CheckK = Istck6 == k;
    %Isolate kth junction voxel cluster on spine-side 
    CheckM = IstckBorder3.*CheckK;
    %Identify distinct interconnecting voxel groups
    CheckM2 = bwlabeln(CheckM,26);
    %Isolate kth junction voxel cluster on shaft-side
    CheckM3 = imdilate(CheckK, se1).*IstckBorder2;
    %Identify distinct interconnecting voxel groups
    CheckM4 = bwlabeln(CheckM3,26);
    
    %Count number of distinct interconnecting voxel groups
    NCheckM2(k) = max(CheckM2, [], 'all');
    NCheckM4(k) = max(CheckM4, [], 'all');
    %If numbers of interconnecting voxel groups are one on either side,
    %this spine is judged to have a single attachment site to the shaft
    if NCheckM2(k) ==1 || NCheckM4(k) ==1
        %Increase spine-side junction four times
        CheckMM = imdilate(CheckM, se4);
        %From spine voxels, subtract voxels close to the junction
        CheckM5 = CheckK - CheckK.*CheckMM;
        %Count number of voxel clusters at distal part
        CheckM6 = bwlabeln(CheckM5,26);
        NCheckM5 = max(max(max(CheckM6)));
        %If distal cluster number is 2, these two clusters are considered
        %as two branches of a spine
        if NCheckM5 == 2 && sum(sum(sum(CheckK))) >1000
            %Separate voxels belong to two spine branches
            CheckM6A = CheckM6 == 1;
            CheckM6B = CheckM6 == 2;
            %Analyze the first (larger) spine branch
            VolumeSpine = sum(sum(sum(CheckM6A)));
            VolumeJunct = sum(sum(sum(imdilate(CheckM6A, se1).*CheckMM)));
            %if the first spine branch is large, it is added to the spine
            %pool
            if VolumeJunct/VolumeSpine < 0.7 && VolumeSpine >1000
                %Add the first cluster to Istck6B
                SpineK = CheckM6A*kcount;
                Istck6B = Istck6B + SpineK.*(1-(Istck6B>0));
                %Add the junction voxels of the first cluster to IstckJunction3
                JunctionK = (imdilate(CheckM6A, se1).*CheckMM)*kcount;
                IstckJunction3 = IstckJunction3 + JunctionK.*(1-(IstckJunction3>0));
                %Increase the spine count by one
                kcount = kcount+1;
            end
            %Analyze the second (smaller) spine branch
            VolumeSpine = sum(sum(sum(CheckM6B)));
            VolumeJunct = sum(sum(sum(imdilate(CheckM6B, se1).*CheckMM)));
            %if the second spine branch is large, it is added to the spine
            %pool
            if VolumeJunct/VolumeSpine < 0.7 && VolumeSpine >1000
                %Add the second cluster to Istck6B
                SpineK = CheckM6B*kcount;
                Istck6B = Istck6B + SpineK.*(1-(Istck6B>0));
                %Add the junction voxels of the second cluster to IstckJunction3
                JunctionK = (imdilate(CheckM6B, se1).*CheckMM)*kcount;
                IstckJunction3 = IstckJunction3 + JunctionK.*(1-(IstckJunction3>0));
                kcount = kcount+1;
            end
                       
        else
            %If distal cluster number is 0 or more than 1, it is judged to be
            %a single spine
            VolumeSpine = sum(sum(sum(CheckK)));
            VolumeJunct = sum(sum(sum(CheckM + CheckM3))); 
            if VolumeJunct/VolumeSpine < 0.7
                %Record the kth spine voxel and put the number of kcount to voxels
                SpineK = (Istck6 == k)*kcount;
                Istck6B = Istck6B + SpineK.*(1-(Istck6B>0));
                %Record the kth spine junction voxel and put the number of kcount
                %to voxels
                JunctionK = ((CheckM + CheckM3)>0)*kcount;
                IstckJunction3 = IstckJunction3 + JunctionK.*(1-(IstckJunction3>0));
                %Increase the spine count by one
                kcount = kcount+1;
            end
        end
        
    end
end
%Change the number of total identified spines
newK = kcount-1;
end
