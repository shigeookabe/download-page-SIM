function [IstckHorizontal1B, IstckHorizontal2B] = a20250428_spinemeasure_sub04(Istck1, Istck1B)

%*************************************************************************
%This function uses "Istck1" and "Istck1B", TIF binary stack files without 
%or with shaft filling, detect the largest object as the main dendritic shaft, 
%and find rotation angle of the dendritic shaft to place it horizontally to 
%the X-axis of the image.
%The outputs of the function are "IstckHorizontal1B" and "IstckHorizontal2B", 
%TIF binary stack file
%*************************************************************************

%Check voxel size of image
Nsize = size(Istck1);
%Make 2D projection
Sthre= sum(Istck1, 3) >0;
%Isolate largest object in 2D projection
Objimg = bwareafilt(Sthre,1);
%Prepare vector for storing variance in Y direction
VarimgY = zeros(19,1);
for k=0:18
    %Rotate 2D image with its angle of k*10 degree
    RotObjimg = imrotate(Objimg, k*10, 'nearest','crop');  
    %Calculate summation of pixel number along Y axis
    SumY = sum(RotObjimg,2).';
    %Calculate variance in Y direction
    VarimgY(k+1) = var(find(SumY));
end

%Find the position and actual value of the smallest variance
[~, MinangleNo] = min(VarimgY);

Nsize2 = size(imrotate(Sthre, (MinangleNo-1)*10, 'nearest','loose'));
IstckHorizontal1 = zeros(Nsize2(1), Nsize2(2), Nsize(3));
IstckHorizontal2 = zeros(Nsize2(1), Nsize2(2), Nsize(3));

%Put rotated images into IstckHorizontal
for k = 1:Nsize(3)
    IstckHorizontal1(:,:,k) = imrotate(Istck1(:,:,k), (MinangleNo-1)*10, 'nearest','loose')>0;
    IstckHorizontal2(:,:,k) = imrotate(Istck1B(:,:,k), (MinangleNo-1)*10, 'nearest','loose')>0;
end

Nsize2 = size(IstckHorizontal1);

%Make vector along X-axis
ProjIstckVertical1 = sum((sum(IstckHorizontal1, 3)), 1)>50;
%Find positions with non-zero values
Nonzero = find(ProjIstckVertical1);
%Find leftmost and rightmost pixels with non-zero values
LeftPixel = min(Nonzero);
RightPixel = max(Nonzero);
if rem((RightPixel-LeftPixel), 2) == 1
    RightPixel = RightPixel-1;
end
%Calculate image X-axis size
Imagesize = RightPixel - LeftPixel +1;
Halfsize = int16((Imagesize-1)/2);

%Make vector along Y-axis
ProjIstckHorizontal1 = sum((sum(IstckHorizontal1, 3)), 2);
%Find the shaft centroid along Y-axis
Centroid = int16(sum(ProjIstckHorizontal1.*([1:1:size(ProjIstckHorizontal1)].'))/sum(ProjIstckHorizontal1));
%Calculate upper and lower point in Y-axis
UpPixel = Centroid - Halfsize;
LowPixel = Centroid + Halfsize;

%Make vector along Z-axis
ProjectZ = squeeze(sum((sum(Istck1, 2)), 1));
%Find the shaft centroid along Z-axis
CentroidZ = int16(sum(ProjectZ.*([1:1:size(ProjectZ)].'))/sum(ProjectZ));
%Find upper and lower z-slice
UpZ = CentroidZ - int16(floor(Nsize(3)/2));
LowZ = CentroidZ + int16(floor(Nsize(3)/2));
UpWidth = CentroidZ - UpZ;
LowWidth = LowZ - CentroidZ;
%If upper and lower z-slices are out of the stack boundary, slice numbers
%are adjusted
if UpZ < 1
    UpZ = 1;
    UpWidth = CentroidZ - 1;
end
if LowZ > Nsize(3)
    LowZ = Nsize(3);
    LowWidth = Nsize(3)-CentroidZ; 
end

%Make new stacks with new size
if rem(Nsize(3),2) ==1
    Zwidth = Nsize(3);
else
    Zwidth = Nsize(3)+1;
end
Zcenter = (Zwidth+1)/2;

%prepare matrix for images
IstckHorizontal1B = zeros(Imagesize, Imagesize, Zwidth);
IstckHorizontal2B = zeros(Imagesize, Imagesize, Zwidth);

%calculate upper and lower limits in Y and Z directions
Yup = Nsize2(1)-UpPixel+1;
Ylow= 2-UpPixel;
Zup = Zcenter-UpWidth;
Zlow = Zcenter+LowWidth;

%if both upper and lower points are within the image
if UpPixel >= 1 && LowPixel <= Nsize2(1)
    IstckHorizontal1B(:,:,Zup:Zlow) = IstckHorizontal1(UpPixel:LowPixel,LeftPixel:RightPixel,UpZ:LowZ);
    IstckHorizontal2B(:,:,Zup:Zlow) = IstckHorizontal2(UpPixel:LowPixel,LeftPixel:RightPixel,UpZ:LowZ); 
end

%if upper point is out of range
if UpPixel < 1 && LowPixel <= Nsize2(1)
    IstckHorizontal1B(Ylow:Imagesize,1:Imagesize,Zup:Zlow) = IstckHorizontal1(1:LowPixel,LeftPixel:RightPixel,UpZ:LowZ);
    IstckHorizontal2B(Ylow:Imagesize,1:Imagesize,Zup:Zlow) = IstckHorizontal2(1:LowPixel,LeftPixel:RightPixel,UpZ:LowZ); 
end

%if lower point is out of range
if LowPixel > Nsize2(1) && UpPixel >= 1 
    IstckHorizontal1B(1:Yup,1:Imagesize,Zup:Zlow) = IstckHorizontal1(UpPixel:Nsize2(1),LeftPixel:RightPixel,UpZ:LowZ);
    IstckHorizontal2B(1:Yup,1:Imagesize,Zup:Zlow) = IstckHorizontal2(UpPixel:Nsize2(1),LeftPixel:RightPixel,UpZ:LowZ);    
end

%if upper and lower points are out of range
if UpPixel < 1 && LowPixel > Nsize2(1)
    IstckHorizontal1B(Ylow:Yup,1:Imagesize,Zup:Zlow) = IstckHorizontal1(1:Nsize2(1),LeftPixel:RightPixel,UpZ:LowZ);
    IstckHorizontal2B(Ylow:Yup,1:Imagesize,Zup:Zlow) = IstckHorizontal2(1:Nsize2(1),LeftPixel:RightPixel,UpZ:LowZ); 
end

%if image is too small
if Imagesize < 500
    IstckHorizontal1B = 0;
    IstckHorizontal2B = 0;
end



