function [Istckmain, IstckA, IstckB, IstckC, IstckD, OptYZ] = a20250428_spinemeasure_sub05(Istckori, Istck, Rplus)
%*************************************************************************
%This function uses "Istckori", "Istck", and Rplus to esimate the shaft
%volume.
%Istckori is the image file after dendrite isolation and rotation.
%Istck is Istckori with shaft center filled with positive voxels.
%Rplus is the value for adjustment of shaft diameter.
%The outputs of the function are "Istckmain", the image stack containing
%both shaft and spines but other voxels removed, "IstckA,B,C,D", the image
%stacks of dendritic shaft with different diameter estimates.
%IstckA is the optimized estimate, B to D are with increasing diameters.
%OptYZ is the YX positions at the center of shaft volume
%*************************************************************************

%Check voxel size of image
Nsize = size(Istck);

%*************************************************************************
%START Rough estimate of the center of dendritic shaft
%*************************************************************************

%Make 2D projection and normalize pixel value to 1
Sthre= sum(Istck, 3) >0;

%Identify the largest object in 2D projection image
Objimg = bwareafilt(Sthre,1);

%Create new 3D matrix
Istck2 = zeros(Nsize(1), Nsize(2), Nsize(3));

%Make 5 times expanded 2D projection template and isolate the 
%original objects that overlap with this template
for k=1:Nsize(3)
 Istck2(:,:,k) = Istck(:,:,k).*bwmorph(Objimg,'thicken',5);
end

%Start obtaining Y and Z values of the dendrite center line with a given X 
%Prepare matrixes for recording positions
posY = zeros(Nsize(1),1);
posZ = zeros(Nsize(1),1);  
avposY = zeros(Nsize(1),1);
avposZ = zeros(Nsize(1),1);
ObjimgYZ = sum(Istck2, 1);

%Fill the gap at the edge of XY projection images
%Fill gap at the left side 25 pixels
    for  k=1:25
        if sum(Objimg(:,k))==0
            Objimg(:,k)=Objimg(:,k+25);
            ObjimgYZ(:,k,:)=ObjimgYZ(:,k+25,:);
        end
    end
%Fill gap at the right side 25 pixels
    for k =Nsize(2)-25:Nsize(2)
         if sum(Objimg(:,k))==0
            Objimg(:,k)=Objimg(:,k-25);
            ObjimgYZ(:,k,:)=ObjimgYZ(:,k-25,:);
         end
    end

%Along the X-axis, calculate the center of the shaft 
    for k=1:Nsize(2)
        if sum(Objimg(:,k))>0           
        %Along Y axis, calculate the mean of the voxel positions
        posY(k) = round(mean(find(Objimg(:,k))));
        %Along Z axis, calculate the mean of the voxel positions
        posZ(k) = round(mean(find(ObjimgYZ(:,k,:))));        
        end
    end
  
%Average the obtained positions of dendrite center line for 113 pixels
    for k=1:56
        avposY(k) = round(mean(posY(1:k+56)));
        avposZ(k) = round(mean(posZ(1:k+56)));
    end
    
    for k=57:Nsize(2)-56
        avposY(k) = round(mean(posY(k-56:k+56)));
        avposZ(k) = round(mean(posZ(k-56:k+56)));
    end
    
    for k=Nsize(2)-55:Nsize(2)
        avposY(k) = round(mean(posY(k-56:Nsize(1))));
        avposZ(k) = round(mean(posZ(k-56:Nsize(1))));
    end

%Create 2D image with positive pixels spread from the shaft center line with width of 200 pixels
%This template is used to isolate the main dendritic shaft and associated spines

%Prepare new 2D image matrix
Objimg2 = zeros(Nsize(1), Nsize(2));

%Put pixel value of 1 within the range of plus/minus 150 pixels from the shaft center line
for k=1:Nsize(2)
    %when the shaft center is in the middle
    if avposY(k) -150 > 0 && avposY(k) + 150 < Nsize(1)
        Objimg2(avposY(k)-150:avposY(k)+150, k) =1;
    end
    %when the shaft center is close to the bottom
    if avposY(k) -150 <= 0 && avposY(k) + 150 < Nsize(1) 
        Objimg2(1:avposY(k)+150, k) =1;
    end
    %when the shaft center is close to the top
    if avposY(k) -150 > 0 && avposY(k) + 150 >= Nsize(1)
       Objimg2(avposY(k)-150:Nsize(1), k) =1;
    end
end

%Prepare new 3D image matrix
Istckmain = zeros(Nsize(1), Nsize(2), Nsize(3));
%From the original 3D image matrix, isolate the volume near the main dendrite
for k=1:Nsize(3)
 Istckmain(:,:,k) = Istckori(:,:,k).*Objimg2;
end

%*************************************************************************
%END Rough estimate of the center of dendritic shaft
%*************************************************************************

%*************************************************************************
%START Fine fitting of dendritic shaft
%Estimate dendritic shaft diameter and ellipticity
%*************************************************************************

%Create a matrix containing ellipses with different diameters (8 -30) and different ellipticity (1:2 to 2:1)
Elip = zeros(161, 41, 12, 5);
%Prepare a vector with different radius
RadialV = [8 10 12 14 16 18 20 22 24 26 28 30];
%Prepare a vector with different ellipticity
Round = [1.4 1 1 1 1;1 1 1.5 2 2.5];

for k=1:12
    for l=1:5
        for j=1:41
            for i=1:161
                if sqrt( (i-81)*(i-81)/((Round(1,l)*RadialV(k)))^2 + (j-21)*(j-21)*16/((Round(2,l)*RadialV(k)))^2 ) <= 1
                Elip(i, j, k, l) = 1;
                end
            end
        end
    end
end

%Prepare vectors necessary for the next calculations
Radius = zeros(Nsize(1),1);
Elliptic = zeros(Nsize(1),1);
OptY = zeros(Nsize(1),1);
OptZ = zeros(Nsize(1),1); 

%Fitting of the prepared 2D ellipse or 3D column with the dendritic shaft
%Fit the best Y and Z positions along X axis from 1 to 30, fitting is done by 2D ellipse
    for k=1:30
        MaxLocal = 0;
        OptY(k) = avposY(k);
        OptZ(k) = avposZ(k);
        for j=-4:4
            for i=-16:16
                %Isolate the plane with X value of k, spanning 33 voxels along Y axis and 9 voxels along Z axis     
                LocalM1 = squeeze(Istck2(avposY(k)+i-16:avposY(k)+i+16, k, avposZ(k)+j-4:avposZ(k)+j+4));
                %Prepare the standard size of circle with radius of 16
                LocalM2 = Elip(65:97,17:25,5,3);
                %Calculate voxel numbers within overlap of real shaft and circle
                %Compare with the previous max value
                if MaxLocal < sum(sum(LocalM1.*LocalM2))
                    %Replace MaxLocal with new value
                    MaxLocal = sum(sum(LocalM1.*LocalM2));
                    %Position of the (Y, Z) corresponding to the center of the shaft is also renewed
                    OptY(k) = avposY(k)+i;
                    OptZ(k) = avposZ(k)+j;
                end
            end
        end
    end
    
%Fit the best Y and Z positions along X axis from 31 to max minus 30
%Fitting is done by 3D column with thickness of 61
    for k=31:Nsize(2)-30
        MaxLocal = 0;
        OptY(k) = avposY(k);
        OptZ(k) = avposZ(k);
        for j=-4:4
            for i=-16:16
                %Isolate cuboid with X value centered at k, spanning plus/minus 30 voxels
                %with size of 33 voxels along Y axis and 9 voxels along Z axis
                LocalM1 = squeeze(Istck2(avposY(k)+i-16:avposY(k)+i+16, k-30:k+30, avposZ(k)+j-4:avposZ(k)+j+4));
                %Prepare the standard size of column with radius of 16 and length of 61
                LocalM2pre = Elip(65:97,17:25,5,3);
                LocalM2 = permute(repmat(LocalM2pre,[1 1 61]), [1 3 2]);
                %Calculate voxel numbers with overlap of real shaft and column
                %Compare with the previous max value
                if MaxLocal < sum(sum(sum(LocalM1.*LocalM2)))
                    %Replace MaxLocal with new value
                    MaxLocal = sum(sum(sum(LocalM1.*LocalM2)));
                    %Position of (Y, Z) corresponding to the center of the shaft is also renewed
                    OptY(k) = avposY(k)+i;
                    OptZ(k) = avposZ(k)+j;
                end
            end
        end
    end  
    
%Fit the best Y and Z positions along X axis from max minus 29 to max, fitting is done by 2D ellipse 
    for k=Nsize(2)-29:Nsize(2)
        MaxLocal = 0;
        OptY(k) = avposY(k);
        OptZ(k) = avposZ(k);
        for j=-4:4
            for i=-16:16
                %Isolate the plane with X value of k, spanning 33 voxels
                %along Y axis and 9 voxels along Z axis
                LocalM1 = squeeze(Istck2(avposY(k)+i-16:avposY(k)+i+16, k, avposZ(k)+j-4:avposZ(k)+j+4));
                %Prepare the standard size of circle with radius of 16
                LocalM2 = Elip(65:97,17:25,5,3);
                %Calculate voxel numbers with overlap of real shaft and circle
                %Compare with the previous max value
                if MaxLocal < sum(sum(LocalM1.*LocalM2))
                    %Replace MaxLocal with new value
                    MaxLocal = sum(sum(LocalM1.*LocalM2));
                    %Position of the (Y, Z) corresponding to the center of the shaft is also renewed
                    OptY(k) = avposY(k)+i;
                    OptZ(k) = avposZ(k)+j;
                end
            end
        end
     end
    
%Check the position along X axis where the center is erroneously shifted toward large spines
     OptYNew = OptY;
%Prepare differential matrix of Y position
     OptYmeandiff = diff(OptY);
%Prepare a vector for judgement of anomalous positions
     judge = zeros(Nsize(1));
     for k=1:Nsize(2)-41
         %Find the gap position where Y values change more than 10
         if abs(OptYmeandiff(k)) > 10 && judge (k+1) == 0
             %Within 40 voxels from this position, find the second position with gap in opposite direction
             judgekk = 0;
             for kk = 1:40
                 if OptYmeandiff(k)*OptYmeandiff(k+kk) < 0 && abs(OptYmeandiff(k+kk)) > 10 && judgekk == 0
                     %If the second gap is found, the Y value between two gaps is set to the average of two points
                     %before and after the two gaps
                     OptYNew(k+1:k+1+kk) = floor((OptY(k) + OptY(k+kk+2))/2);
                     %Set judge vector to be 1 from the first voxel to the
                     %second gap
                     judge(1:k+kk+1) = 1;
                     %Set judgekk parameter to be 1 to avoid finding the third gap
                     judgekk = 1;
                 end                 
             end
             
         end
     end
    
%In the previous part, Y and Z positions are estimated
%In the next section, optimal radius and ellipticity are estimated
  for k=1:Nsize(2)        
        MaxLocalSize = 0;
        Radius(k) = 2;
        Elliptic (k) = 1;
        for j=1:8
            for i=1:5
                %Isolate the plane with X value of k, spanning 121 voxels along Y axis
                %and 31 voxels along Z axis
                LocalM1 = squeeze(Istck2(OptYNew(k)-60:OptYNew(k)+60, k, OptZ(k)-15:OptZ(k)+15));
                %Prepare the ellipse with specific radius and ellipcity 
                LocalM2 = Elip(21:141, 6:36, j, i);
                %Calculate voxel numbers within overlap of real shaft and ellipse
                LocalSize = sum(sum(LocalM1.*LocalM2));
                TotalSize = sum(sum(LocalM2));
                %Calculate ratio of overlapping voxel and total model ellipse
                LocalRatio = LocalSize/TotalSize;
                %If overlap is larger than the previous trial and the ratio is more than 0.6, 
                %replace the recorded radius and ellipticity with new values
                if MaxLocalSize < LocalSize && LocalRatio > 0.6
                    MaxLocalSize = LocalSize;
                    Radius(k) = j+1;
                    Elliptic (k) = i;
                end
            end
        end    
  end
  
  %Smoothing the shaft shape by averaging Y position, radius, and ellipticity
  OptYNew = round(movmean(OptYNew, 30));
  Radius = round(movmean(Radius, 30));
  Elliptic = round(movmean(Elliptic, 30));
  
  OptYZ = [OptYNew.' ; OptZ.'];
  
  %Create 3D model of dendritic shaft with best-fit radius
  Istck3A = zeros(Nsize(1), Nsize(2), Nsize(3));
  for k=1:Nsize(2)
     Istck3A(OptYNew(k)-60:OptYNew(k)+60, k, OptZ(k)-15:OptZ(k)+15) = Elip(21:141, 6:36,Radius(k)+Rplus,Elliptic(k));
  end
  
%image is dilated for 1 pixel
se1 = strel("sphere", 1);
Istck3A = imdilate(Istck3A, se1);
Istck3B = imdilate(Istck3A, se1);
Istck3C = imdilate(Istck3B, se1);
Istck3D = imdilate(Istck3C, se1);

%Pass through median filter to further remove local misalignment
IstckA = medfilt3(Istck3A,[15 15 5]);
IstckB = medfilt3(Istck3B,[15 15 5]);
IstckC = medfilt3(Istck3C,[15 15 5]);
IstckD = medfilt3(Istck3D,[15 15 5]);

%*************************************************************************
%END Fine fitting of dendritic shaft
%Estimate dendritic shaft diameter and ellipticity
%************************************************************************* 