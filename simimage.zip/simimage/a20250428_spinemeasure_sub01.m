function [IstckOut] = a20250428_spinemeasure_sub01(Istck)
%This subfunction apply max filter to increase intensity inside of
%dendritic shaft
% This step is necessary for DiI staining that make dendritic surface
% fluorescent
Nsize = size(Istck);

IstckAdd = zeros(Nsize(1)+4, Nsize(2)+4, Nsize(3)+8);
IstckOut = zeros(Nsize(1), Nsize(2), Nsize(3));
IstckAdd(3:Nsize(1)+2, 3:Nsize(2)+2, 5:Nsize(3)+4) = Istck;
for k = 5:Nsize(3)+4
    for j = 3:Nsize(2)+2
        for i = 3:Nsize(1)+2
            A = IstckAdd(i-2:i+2, j-2:j+2, k-4:k+4);
            IstckOut(i-2, j-2, k-4) = max(A(:));
        end
    end
end



