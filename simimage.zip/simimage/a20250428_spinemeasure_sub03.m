function [IstckCrop1, IstckCrop1B] = a20250428_spinemeasure_sub03(Istck1, Istck1B)

%This subfunction detect the largest fluorescent object and isolate as a
%target dendrite

%initial random number
rng('shuffle')
%disk object generation
SE = strel('disk',1);
SE4 = strel('disk',4);
%check the size of matrix Istck1
Nsize = size(Istck1);
%make projection image
ProjI = max(Istck1,[], 3);

%Generate small size (1/16) image and show
SmallI = imresize(imdilate(ProjI, SE4), 0.0625);
%Eliminate peripheral pixels with lower intensity
SmallI2 = SmallI>0.3;
%Identify independent pixel cluster, largest
Seg1 = bwareafilt(SmallI2,1);
%prepare matrix for 50000 repeats of area sampling
Mscore = zeros(50000, 5);
count=0;
%If the largest pixel cluster is larger than 30% of the total cluster size, start
%sampling
if sum(sum(sum(Seg1)))> 0.3*sum(sum(sum(SmallI2)))
    %fill the holes in the largest cluster
    Seg1B = imclose(Seg1, SE);
    %repeat 50000 sampling
    for k = 1:50000
    %select the left upper corner (XY) = (J1, I1)
    J1 = round(rand(1)*31+1);
    I1 = round(rand(1)*31+1);
    %select the right lower corner (XY) = (J2, I2)
    J2 = J1 + 32 + round(rand(1)*(32-J1));
    I2 = I1 + 32 + round(rand(1)*(32-I1));
    %copy the selected image area and also invert the image
    Itest1 = Seg1B(J1:J2, I1:I2);
    Itest2 = ~Seg1B(J1:J2, I1:I2);

    %define four corner points
    C1 = Seg1B(J1, I1);
    C2 = Seg1B(J1, I2);
    C3 = Seg1B(J2, I2);
    C4 = Seg1B(J2, I1);
    %define 8 segments along the periphery of the rectangle
    S1 = sum(Seg1B(J1,I1:I1+5))+ sum(Seg1B(J1+1:J1+5,I1));
    S2 = sum(Seg1B(J1,I1+6:I2-6));
    S3 = sum(Seg1B(J1,I2-5:I2))+ sum(Seg1B(J1+1:J1+5,I2));
    S4 = sum(Seg1B(J1+6:J2-6,I2));
    S5 = sum(Seg1B(J2-5:J2,I2))+ sum(Seg1B(J2,I2-5:I2-1));
    S6 = sum(Seg1B(J2,I1+6:I2-6));
    S7 = sum(Seg1B(J2,I1:I1+5))+ sum(Seg1B(J2-5:J2-1,I1));
    S8 = sum(Seg1B(J1+6:J2-6,I1));
    %if Judge = 0, the rectangle does not crop dendrite appropriately
    Judge = 0;
    
    %the case of dendrite passing left upper and right lower corners
    if C1>0 && C3>0
        if S2+S3+S4+S6+S7+S8 == 0
        Judge = 1;
        end
    end
    %the case of dendrite passing right upper and left lower corners
    if C2>0 && C4>0
        if S8+S1+S2+S4+S5+S6 == 0
        Judge = 1;
        end
    end
    %the case of dendrite only passing left upper corner
    if C1>0 && C2==0 && C3==0 && C4==0
        if S2+S3+S5+S7+S8 == 0
        Judge = 1;
        end
    end
    %the case of dendrite only passing right upper corner
    if C2>0 && C1==0 && C3==0 && C4==0
        if S4+S5+S7+S1+S2 == 0
        Judge = 1;
        end
    end
    %the case of dendrite only passing right lower corner
    if C3>0 && C1==0 && C2==0 && C4==0
        if S6+S7+S1+S3+S4 == 0
        Judge = 1;
        end
    end
    %the case of dendrite only passing left lower corner
    if C4>0 && C1==0 && C2==0 && C3==0
        if S8+S1+S3+S5+S6 == 0
        Judge = 1;
        end
    end
    %the case of dendrite not passing all four corners
    if C1==0 && C2==0 && C3==0 && C4==0
        if (S1+S2+S3==0 && S5+S6+S7==0) || (S3+S4+S5 ==0 && S7+S8+S1==0)
        Judge = 1;
        end
    end
    
    %if single dendritic segment is isolated, Ntest1 = 1
    Ntest1 = max(max(bwlabeln(Itest1)));
    %if single dendrite separate the field into two areas, Ntest2 = 2
    Ntest2 = max(max(bwlabeln(Itest2)));
    %if positive image pixels are more than 5% of the toal pixels, Ntest3=1
    [size1 size2] = size(Itest1);
    Ntest3 = sum(Itest1, 'all') > size1*size2*0.05;
    
    %if the following conditions are cleared, the sampling was successful
    if Ntest1 == 1 && Ntest2 == 2 && Judge ==1 && Ntest3 == 1
        count = count+1;
        %record the position of four corners and relative size of the area
        Mscore(count,:) = [J1 I1 J2 I2 (J2-J1)*(I2-I1)/(64*64)];
    end
    end 
    %identify the sampled rectangle with largest area
    [M, I] = max(Mscore(:,5));

    %record the position of four corners of the best sample
    Position64 = Mscore(I, 1:4);
    %convert the position to original 1024X1024 pixel size
    Position1024 = Position64*16-8;
    %check Position1024 is within the range of the image
    if Position1024(3)>Nsize(1)
        Position1024(3) = Nsize(1);
    end
    if Position1024(4)>Nsize(2)
        Position1024(4) = Nsize(2);
    end

    %check if no appropriate cropping was performed
    if Position1024(3)>500 && Position1024(4)>500

        %eliminate other dendritic components belonging to different pixel clusters
        Segrest1024  = imresize(SmallI2-Seg1, 16)>0;
        Segrest1024Z = repmat(~Segrest1024, [1 1 Nsize(3)]);

        Istck1Sub = Istck1.*Segrest1024Z;
        Istck1BSub = Istck1B.*Segrest1024Z;

        %from the original size image, crop the best position
        IstckCrop1 = Istck1Sub(Position1024(1):Position1024(3), Position1024(2):Position1024(4),:);
        IstckCrop1B = Istck1BSub(Position1024(1):Position1024(3), Position1024(2):Position1024(4),:);
    else
        %if cropping was not successful, skip this image
        IstckCrop1 = 0;
        IstckCrop1B = 0;
    end

end
%If the largest pixel cluster is smaller than 30% of the total cluster
%size, skip this image
if sum(sum(sum(Seg1))) <= 0.3*sum(sum(sum(SmallI2)))
    IstckCrop1 = 0;
    IstckCrop1B = 0;
end

