function [Istck6B,IstckJunction] = a20250428_spinemeasure_sub08(Istck6, IstckBorder, newK)

%***********************************************************************
%Using voxels for spines (Istck6) and dendritic shaft (IstckBorder),
%spine-shaft junctions are adjusted
%newK is the number of spine candidates
%Outputs are both spine voxels and junction voxels after adjustment
%***********************************************************************

%Spine candidate voxels are expanded by using sphere structure, 
%and overlap with non-spine volume is isolated

se2 = strel('sphere',2);
Nsize = size(Istck6);
%Isolate shaft-side volume
IstckJunction = imdilate(Istck6, se2).*IstckBorder;
%Dilate shaft volume
ShaftDilate = imdilate(IstckBorder, se2);
if newK > 0
for k = 1:newK
    
    %Isolate kth voxel cluster of spine
    SpineM = Istck6 == k;
    %Isolate kth junciton
    AccumM = zeros(Nsize(1), Nsize(2), Nsize(3));
    
    %if spine is small, adjust the boundary
    SumCheckM1 = sum(sum(sum(SpineM)));
    if SumCheckM1 < 3000
        
    %Isolate spine-side volume
    SpineJunct = ShaftDilate.* SpineM;
    %Calculate the total voxel numbers of the isolated clusters
    SumSpine = sum(sum(sum(SpineJunct,3),2),1);
    
    for m = 1:6
        
    %Isolate shaft-side volume
    ShaftJunct = IstckJunction==k;

    %Calculate the total voxel numbers of the isolated clusters
    SumShaft = sum(sum(sum(ShaftJunct,3),2),1);
    
    %Judge if the isolated voxel cluster on shaft-side is of similar size
    %to spine-side cluster        
        if SumSpine/SumShaft > 0.5 && sum(sum(sum(Istck6.*ShaftJunct))) == 0
       
        %Add this shaft-side cluster to spine cluster
        Istck6 = Istck6 + ShaftJunct*k;
        
        %Add new voxel to AccumM
        AccumM = AccumM + ShaftJunct;
        
        %Redefine the shaft-side cluster
        ShaftJunct =imdilate(Istck6==k, se2).*IstckBorder - AccumM;
            
        %Replace previous shaft-side cluster with a newly defined cluster
        IstckJunction = IstckJunction - (IstckJunction==k)*k + ShaftJunct*k;
     
        end
    end   
    end
end

end
Istck6B = Istck6;


