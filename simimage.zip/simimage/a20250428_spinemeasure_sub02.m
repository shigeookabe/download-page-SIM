function [ImageOut] = a20250428_spinemeasure_sub02(ImageMat, Coeff)

%*************************************************************************
%This function input single stack files and apply autothresholding
%ImageMat is the input image stack for thresholding
%Coeff is the extent of reducing the threshold 
%Value 0.5 means half of theoriginial threshold
%*************************************************************************

%Obtain pixel sizes of ImageMat
Nsize = size(ImageMat);

stthresh = zeros(Nsize(3));
for k = 1:Nsize(3)
    %Apply multithreshold to "imagebuffer"
    thresh = multithresh( ImageMat(:,:,k),2);
    %the smaller value of two thresholds is stored in "stthresh"
    stthresh (k) = thresh(1);
end
%Change the order of elements in "stthresh" in a descending manner
stthreshB = sort(stthresh, 'descend');
%The first three elements are selected and averaged to be 
%used as a common threshold for all images
avestthreshB = mean(stthreshB(1:3));

ImageOut = zeros(Nsize(1), Nsize(2), Nsize(3));
%*************************************************************************
%START loading each image, apply multi-thresholding and active contour
%Output binalized image stack
%*************************************************************************
for k=1:Nsize(3)
    %Select pixels with intensities higher than 
    %threshold "avestthresB" multiplied by a coefficient
    %Coefficient is 1.1 for GFP (1.7 for DiI)
    Ithresh = ImageMat(:,:,k) > avestthreshB*Coeff;
    %Apply active contour with images containing non-zero pixels
    if sum(Ithresh) >0
        %Apply active contour manipulation
        %4th parameter is either 'edge' or 'Chan-Vese'
        ImageOut(:,:,k) = activecontour(ImageMat(:,:,k), Ithresh, 20, 'edge');       
    else
        ImageOut(:,:,k) = Ithresh;
    end
end
%*************************************************************************
%END loading each image, apply multi-thresholding and active contour
%Output binalized image stack
%************************************************************************

