function [SpineMat] = a20250428_spinemeasure_sub12(Apex, Base, Sum, Matnumber,newK2, Nsize, totalK)  

%This function is a subroutine of "a20250428_spinemeasure_sub11"
%Calculate multiple structural parameters and output "SpineMat" cell 
%This function also produce pseudocolor images of spines

%prepare matrix to record results of measurement
SpineMat = cell(5);
%calculate total voxels of the sum
        SumN = sum(Sum, 'all');
        %prepare matrix to store longitutinal profile of "base" cell
        baseprofile = zeros(20,2);
        %record spine length
        Spinelength = find((Matnumber(:,1)>0), 1, 'last');
        %find most distal base segment with pixel counts >100
        Nrange = find((Matnumber(:,2)>100), 1, 'last');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START spine segments to project to PCA and calculate convexhull
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %Using PCA, the curved spine segments are straightened
    for i = 1:Nrange  
        Baseindex = find(Base{i});
        %find xyz coordinate of positive pixels in Base{i} for PCA
        %ind2sub = convert linear indices to subscripts
        [numY, numX, numZ] = ind2sub(Nsize, Baseindex);
        %fit plane to positive voxels using PCA (making planar projection of
        %the Base segment
        [~,score,~] = pca([numY, numX, numZ]);
        %find range of x and y in PCA plane
        MinY = floor(min(score(:,1))); MaxY = floor(max(score(:,1))); MinX = floor(min(score(:,2))); MaxX = floor(max(score(:,2)));
        %create new 2D matrix to convert point positions to image pixels
        NewXY = zeros(MaxY-MinY+1, MaxX-MinX+1);
        CountBW= zeros(MaxY-MinY+1, MaxX-MinX+1);
        %put value 1 to each pixel
        Ssize = size(score);
        %Start adding pixel data to 2D matrix
        for j = 1:Ssize(1)
            %accumulate '1' to pixel specified by pixel positions after PCA to
            %NewXY matrix
            NewXY(floor(score(j,1))-MinY+1, floor(score(j,2))-MinX+1) = NewXY(floor(score(j,1))-MinY+1, floor(score(j,2))-MinX+1)+1; 
            %record the pixel positions after PCA by input '1' to CountBW
            %matrix
            CountBW(floor(score(j,1))-MinY+1, floor(score(j,2))-MinX+1) = 1;
        end
    
        %calculate ratio of total area against projected pixes
        AreaRatio = (MaxY-MinY+1)*(MaxX-MinX+1)/sum(CountBW, 'all');
        %select pixels with their values higher than 33% of the average
        NewXY = NewXY/(mean(NewXY,'all')*AreaRatio)>0.33;
        %calculate total pixel number of projected image
        NNewXY = sum(NewXY, 'all');
        %define convexhull area
        CH = bwconvhull(NewXY);
        %calculate totat pixel number of CH
        NCH = sum(CH, 'all');
        Ratio = (NCH-NNewXY)/NCH;
        %output convexhull ratio and convexhull-total volume
        baseprofile(i,:) = [Ratio 0.03*0.03*0.03*Matnumber(i,2)*Ratio];
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END spine segments to project to PCA and calculate convexhull
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START calculate surface area
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Surfcount = 0;
    for n=2:Nsize(3)-1
        for m=2:Nsize(2)-1
            for l=2:Nsize(1)-1
                if Apex{1}(l, m, n) ==1
                    %from 6 sufaces of a cube, subtract surfaces attached
                    %to the adjacent voxel
                    freeface = 6-(Apex{1}(l-1, m, n)+Apex{1}(l+1, m, n)+Apex{1}(l, m-1, n)+Apex{1}(l, m+1, n)+Apex{1}(l, m, n-1)+Apex{1}(l, m, n+1));
                    Surfcount = Surfcount + freeface;
                end
            end
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END calculate surface area
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %isolate the most basal interface between Apex and Base
    se1 = strel('sphere',1);
    Junctsurface = sum(imdilate(Apex{1}, se1).*Base{1},'all');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START calculate morphological parameters
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %record spine length (1st row)
    SpineMat{1} = 0.03*5*Spinelength;
    %record surface area of spine and junction (2nd row)
    SpineMat{2} = 0.03*0.03*[Surfcount-Junctsurface Junctsurface];
    %record spine volume (3rd row) 
    SpineMat{3} = 0.03*0.03*0.03*Matnumber(1,1);
    %record volume for each segment (4th row)
    SpineMat{4} = 0.03*0.03*0.03*Matnumber(:,2);
    %record convexhull ratio and its volume for each segment (5th row)
    SpineMat{5} = baseprofile;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END calculate morphological parameters
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START create pseudocolor spine projection image and save
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %image should be normalized
    %./(sum(Sum>0, 3)) -> devide by projection image to Z direction to
    %normalize voxel number in this direction
    pseudCimage = ((sum(Sum, 3)*1000/SumN)./(sum(Sum>0, 3)));
    maxpCi = max(pseudCimage, [] ,'all');
    pseudCimage  = uint8(pseudCimage/maxpCi*255)+1;
    
    %generate pseudocolor file
    Output = zeros([size(pseudCimage,1) size(pseudCimage, 2) 3]);
    map = parula(256);
    Red = map(:,1); Green = map(:,2); Blue = map(:, 3);
    Output(:,:,1) = Red(pseudCimage); Output(:,:,2) = Green(pseudCimage); Output(:,:,3) = Blue(pseudCimage);
    Output = im2uint8(Output);
    
    %save pseudocolor spine image
    inputname = 'spineimage';
    namenumber = sprintf('%d', totalK+newK2);
    nametif = '.tif';
    fname= [inputname namenumber nametif];
    imwrite(Output, fname);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END create pseudocolor spine projection image and save
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%